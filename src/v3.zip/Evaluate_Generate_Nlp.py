# File: evaluate_generate_nlp.py
import os
from transformers import GPT2Tokenizer
from custom_gpt2_lmhead import CustomGPT2LMHeadModel

model_path = os.path.abspath("./output/oscillatory_gpt2/final_model")
model = CustomGPT2LMHeadModel.from_pretrained(model_path)
tokenizer = GPT2Tokenizer.from_pretrained(model_path)
tokenizer.pad_token = tokenizer.eos_token

prompt = "The future of AI in natural language processing is"
inputs = tokenizer(prompt, return_tensors="pt")
outputs = model.generate(**inputs, max_length=50, num_return_sequences=1)
print("Generated:", tokenizer.decode(outputs[0], skip_special_tokens=True))