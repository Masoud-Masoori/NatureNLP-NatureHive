import torch
import torch.nn as nn
from transformers import GPT2LMHeadModel, GPT2Config
from oscillatory_layer_v3 import OscillatoryLayer

class CustomGPT2LMHeadModel(GPT2LMHeadModel):
    def __init__(self, config):
        super().__init__(config)
        self.oscillatory = OscillatoryLayer(config)  # Pass full config to Oscillatory Layer
        self.osc_to_vocab = nn.Linear(config.hidden_size, config.vocab_size)

    def forward(self, input_ids=None, attention_mask=None, labels=None, output_hidden_states=False, **kwargs):
        # Always request hidden states
        outputs = super().forward(
            input_ids=input_ids,
            attention_mask=attention_mask,
            labels=labels,
            output_hidden_states=True,
            **kwargs
        )

        # During training/evaluation (hidden_states are available)
        if outputs.hidden_states is not None:
            hidden_states = outputs.hidden_states[-1]  # last layer hidden state (batch, seq_len, hidden_size)
            oscillatory_output = self.oscillatory(hidden_states)  # Apply oscillatory layer
            osc_logits = self.osc_to_vocab(oscillatory_output)   # Project oscillatory output to vocab space

            combined_logits = outputs.logits + osc_logits  # Combine base GPT-2 logits with oscillatory logits
            return {"logits": combined_logits}

        # During generation (no hidden_states), return outputs directly
        return outputs
