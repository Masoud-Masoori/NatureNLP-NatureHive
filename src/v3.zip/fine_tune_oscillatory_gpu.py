import os
import torch
from datasets import load_dataset
from transformers import GPT2Tokenizer, Trainer, TrainingArguments, DataCollatorForLanguageModeling
from custom_gpt2_lmhead import CustomGPT2LMHeadModel

# Load dataset
dataset = load_dataset("imdb")

# Reduce dataset size for testing
train_dataset = dataset["train"].shuffle(seed=42).select(range(2000))  # Reduced to 2000 samples
test_dataset = dataset["test"].shuffle(seed=42).select(range(1000))  # Reduced to 1000 samples

# Load tokenizer
model_path = os.path.abspath("./base_model/gpt2_medium")
tokenizer = GPT2Tokenizer.from_pretrained(model_path)
tokenizer.pad_token = tokenizer.eos_token

def tokenize_function(examples):
    return tokenizer(examples["text"], padding="max_length", truncation=True, max_length=512)

train_dataset = train_dataset.map(tokenize_function, batched=True)
test_dataset = test_dataset.map(tokenize_function, batched=True)

# Load model
model = CustomGPT2LMHeadModel.from_pretrained(model_path)
model.resize_token_embeddings(len(tokenizer))

# Set up training arguments
training_args = TrainingArguments(
    output_dir="./output/oscillatory_gpt2_finetuned",
    overwrite_output_dir=True,
    num_train_epochs=1,
    per_device_train_batch_size=8,  # Increased batch size
    per_device_eval_batch_size=8,
    save_strategy="epoch",
    logging_dir="./logs",
    logging_steps=50,
    gradient_accumulation_steps=2,  # Simulate larger batch size
    fp16=True,  # Enable mixed precision
    max_steps=500  # Limit steps for quick testing
)

data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)

# Initialize Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=test_dataset,
    data_collator=data_collator,
    tokenizer=tokenizer
)

# Train
trainer.train()

# Save the final model
model.save_pretrained("./output/oscillatory_gpt2/final_model")
tokenizer.save_pretrained("./output/oscillatory_gpt2/final_model")
