import torch
import torch.nn as nn
import math

class OscillatoryLayer(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.hidden_size = config.hidden_size  # Access hidden_size from config

        # Oscillatory components
        self.frequency = nn.Parameter(torch.randn(self.hidden_size))
        self.phase = nn.Parameter(torch.randn(self.hidden_size))
        self.linear = nn.Linear(self.hidden_size, self.hidden_size)

        # Fractal memory
        self.fractal_memory = nn.Parameter(torch.randn(4, self.hidden_size))  # 4 scales
        # Initialize and normalize BEFORE wrapping as Parameter
        initial_memory = torch.randn(4, self.hidden_size)
        normalized_memory = nn.functional.normalize(initial_memory, p=2, dim=-1)
        self.fractal_memory = nn.Parameter(normalized_memory)

        # Golden Angle scaling (optional)
        golden_angle = math.pi * (3 - math.sqrt(5))
        self.golden_scale = nn.Parameter(torch.full((self.hidden_size,), golden_angle))
      

    def forward(self, hidden_states):
        # Apply oscillation: sin(frequency * t + phase)
        batch_size, seq_len, hidden_size = hidden_states.size()
        time = torch.arange(seq_len, dtype=hidden_states.dtype, device=hidden_states.device)
        time = time.unsqueeze(0).unsqueeze(-1)  # shape: (1, seq_len, 1)

        oscillation = torch.sin(time * self.frequency + self.phase)

        # Broadcast oscillation to batch
        oscillation = oscillation.squeeze(0)  # Remove the first singleton dim
        oscillation = oscillation.expand(batch_size, *oscillation.shape)


        # Apply linear transformation
        output = self.linear(hidden_states * oscillation)

        # Add fractal memory effect
        output += self.fractal_memory.unsqueeze(0).unsqueeze(0)

        # Apply golden angle scaling
        output *= self.golden_scale.unsqueeze(0).unsqueeze(0)

        return output
