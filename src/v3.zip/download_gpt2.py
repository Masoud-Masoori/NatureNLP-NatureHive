# File: download_gpt2.py
from transformers import GPT2Tokenizer, GPT2Model

tokenizer = GPT2Tokenizer.from_pretrained("gpt2-medium")
model = GPT2Model.from_pretrained("gpt2-medium")
model.save_pretrained("./base_model/gpt2_medium")
tokenizer.save_pretrained("./base_model/gpt2_medium")
