# File: custom_gpt2.py
from transformers import GPT2Model

class CustomGPT2Model(GPT2Model):
    def __init__(self, config):
        super().__init__(config)