import torch
from transformers import GPT2Tokenizer, GPT2Config, GPT2LMHeadModel
from custom_gpt2_lmhead_v5 import CustomGPT2LMHeadModelV5
import time
import math

# Load tokenizer
tokenizer = GPT2Tokenizer.from_pretrained("gpt2")
tokenizer.pad_token = tokenizer.eos_token

# Load GPT-2 baseline
baseline_model = GPT2LMHeadModel.from_pretrained("gpt2")
baseline_model.eval()

# Load config
config = GPT2Config.from_pretrained("./output_v5/fine_tuned_gpt2/final_model")

# Load model with safetensors
model = CustomGPT2LMHeadModelV5.from_pretrained("./output_v5/fine_tuned_gpt2/final_model", config=config)
model.eval()
# Load NatureNLP v5 custom model
naturenlp_model = CustomGPT2LMHeadModelV5.from_pretrained("./output_v5/fine_tuned_gpt2/final_model", config=config)
naturenlp_model.eval()

# Evaluation prompts
prompts = [
    "Discuss the role of AI in modern healthcare.",
    "Explain the principles of quantum computing in simple terms.",
    "What are the ethical implications of artificial intelligence?",
    "Describe the rhythms of nature and how they influence life."
]

# Metrics storage
metrics = {
    "model": [], "prompt": [], "latency": [], "tokens_sec": [], "loss": [], "perplexity": [], "dead_neurons": []
}

softmax = torch.nn.Softmax(dim=-1)

for model_name, model in zip(["GPT-2 Baseline", "NatureNLP v5"], [baseline_model, naturenlp_model]):
    for prompt in prompts:
        inputs = tokenizer(prompt, return_tensors="pt", padding=True)

        # Measure latency
        start_time = time.time()
        with torch.no_grad():
            outputs = model(input_ids=inputs.input_ids, attention_mask=inputs.attention_mask, output_hidden_states=True)
            logits = outputs["logits"] if isinstance(outputs, dict) else outputs.logits

            hidden_states = outputs.hidden_states[-1] if hasattr(outputs, 'hidden_states') else None
        end_time = time.time()

        latency = end_time - start_time
        num_tokens = inputs.input_ids.numel()
        tokens_sec = num_tokens / latency

        # Loss & perplexity
        labels = inputs.input_ids
        loss_fct = torch.nn.CrossEntropyLoss()
        shift_logits = logits[..., :-1, :].contiguous()
        shift_labels = labels[..., 1:].contiguous()
        loss = loss_fct(shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1))
        perplexity = math.exp(loss.item())

        # Dead neurons (NatureNLP only)
        dead_count = 0
        if model_name == "NatureNLP v5" and hidden_states is not None:
            oscillated = model.oscillatory(hidden_states)
            neuron_activity = oscillated.abs().sum(dim=(0, 1))
            dead_count = (neuron_activity == 0).sum().item()

        # Store metrics
        metrics["model"].append(model_name)
        metrics["prompt"].append(prompt)
        metrics["latency"].append(latency)
        metrics["tokens_sec"].append(tokens_sec)
        metrics["loss"].append(loss.item())
        metrics["perplexity"].append(perplexity)
        metrics["dead_neurons"].append(dead_count if model_name == "NatureNLP v5" else None)

        print(f"[{model_name}] Prompt: {prompt}\nLatency: {latency:.4f}s, Tokens/sec: {tokens_sec:.2f}, Perplexity: {perplexity:.4f}, Dead Neurons: {dead_count if model_name == 'NatureNLP v5' else 'N/A'}\n")

# Aggregate results
import pandas as pd
df = pd.DataFrame(metrics)
print("\n===== Aggregated Metrics =====")
print(df.groupby("model").agg({
    "latency": "mean",
    "tokens_sec": "mean",
    "loss": "mean",
    "perplexity": "mean",
    "dead_neurons": "mean"
}))

# Save results
df.to_csv("evaluation_results.csv", index=False)
