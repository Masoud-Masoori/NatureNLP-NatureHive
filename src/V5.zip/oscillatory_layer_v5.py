import torch
import torch.nn as nn
import torch.nn.functional as F

class OscillatoryLayerV5(nn.Module):
    def __init__(self, config_or_hidden_size, num_experts=4, freq_bands=None, device="cpu"):
        super(OscillatoryLayerV5, self).__init__()

        # Check if input is config or hidden_size
        if hasattr(config_or_hidden_size, "hidden_size"):
            self.hidden_size = config_or_hidden_size.hidden_size
        else:
            self.hidden_size = config_or_hidden_size  # direct hidden_size

        self.device = device

        # Sacred Geometry: Metatron Cube Attention (12-way projections)
        self.projections = nn.ModuleList([
            nn.Linear(self.hidden_size, self.hidden_size) for _ in range(12)
        ])

        # Multi-frequency oscillatory parameters
        if freq_bands is None:
            freq_bands = [4.0, 8.0, 16.0, 32.0]  # Default theta/gamma harmonics
        self.freq_bands = torch.tensor(freq_bands, device=device)
        self.phase_shift = nn.Parameter(torch.randn(self.hidden_size))

        # Low-rank tensor decomposition (massless processing)
        self.low_rank_factor = nn.Parameter(torch.randn(self.hidden_size, self.hidden_size // 4))
        self.reconstruct = nn.Parameter(torch.randn(self.hidden_size // 4, self.hidden_size))

        # Expert gating (frequency-based MoE)
        self.num_experts = num_experts
        self.expert_gates = nn.Linear(self.hidden_size, num_experts)
        self.experts = nn.ModuleList([
            nn.Sequential(
                nn.Linear(self.hidden_size, self.hidden_size),
                nn.ReLU(),
                nn.Linear(self.hidden_size, self.hidden_size)
            ) for _ in range(num_experts)
        ])

    def forward(self, x, timestep=0, temperature=1.0):
        # Metatron Attention: Project along 12 sacred geometry axes
        projections = [proj(x) for proj in self.projections]
        attention_output = torch.stack(projections, dim=0).mean(0)  # mean of projections

        # Oscillatory modulation (wave harmonics)
        freq_mod = torch.sin(2 * torch.pi * self.freq_bands[timestep % len(self.freq_bands)] * x + self.phase_shift)
        oscillated_output = attention_output * freq_mod

        # Low-rank decomposition (massless pathway)
        low_rank_output = torch.matmul(oscillated_output, self.low_rank_factor)
        reconstructed_output = torch.matmul(low_rank_output, self.reconstruct)

        # Ensure consistent input shape: [batch, seq_len, hidden]
        if reconstructed_output.dim() == 2:
            reconstructed_output = reconstructed_output.unsqueeze(1)  # Add seq_len dimension if missing

        batch_size, seq_len, hidden_dim = reconstructed_output.size()

        # Expert gating (Sparse MoE) with temperature scaling
        gate_logits = self.expert_gates(reconstructed_output)  # [batch, seq_len, num_experts]
        gate_probs = F.softmax(gate_logits / temperature, dim=-1)  # [batch, seq_len, num_experts]

        # Compute expert outputs [batch, num_experts, seq_len, hidden]
        expert_outputs = []
        for expert in self.experts:
            out = expert(reconstructed_output)
            if out.shape[-1] != self.hidden_size:
                raise ValueError(f"Expert output hidden size mismatch: expected {self.hidden_size}, got {out.shape[-1]}")
            expert_outputs.append(out)
        expert_outputs = torch.stack(expert_outputs, dim=1)  # [batch, num_experts, seq_len, hidden]

        # Align gate_probs for broadcasting: [batch, seq_len, num_experts, 1] -> [batch, num_experts, seq_len, 1]
        gate_probs = gate_probs.permute(0, 2, 1).unsqueeze(-1)  # [batch, num_experts, seq_len, 1]

        # Weighted sum
        weighted_expert_outputs = gate_probs * expert_outputs  # [batch, num_experts, seq_len, hidden]
        expert_output = weighted_expert_outputs.sum(dim=1)  # Sum over experts -> [batch, seq_len, hidden]

        return expert_output
