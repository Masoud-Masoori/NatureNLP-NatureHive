from transformers import GPT2Tokenizer, Trainer, TrainingArguments
from datasets import load_dataset
import torch
from custom_gpt2_lmhead_v5 import CustomGPT2LMHeadModelV5

# Load dataset
dataset = load_dataset("imdb")
tokenizer = GPT2Tokenizer.from_pretrained("gpt2")
tokenizer.pad_token = tokenizer.eos_token  # Fix padding token issue

def tokenize_function(examples):
    return tokenizer(examples["text"], padding="max_length", truncation=True, max_length=512)

tokenized_datasets = dataset.map(tokenize_function, batched=True, remove_columns=["text"])

# Load model
model = CustomGPT2LMHeadModelV5.from_pretrained("gpt2")

# TrainingArguments without evaluation strategy
training_args = TrainingArguments(
    output_dir="./output_v5/fine_tuned_gpt2",
    overwrite_output_dir=True,
    num_train_epochs=4,
    per_device_train_batch_size=2,
    save_steps=500,
    save_total_limit=2,
    learning_rate=2e-5,           # Lower LR for stability
    weight_decay=0.01,            # Weight decay regularization
    gradient_accumulation_steps=2,
    logging_steps=10,
    report_to="none",
    fp16=True,                    # Enable FP16 mixed precision
    gradient_checkpointing=True,  # Save memory
    optim="adamw_torch",
    max_grad_norm=0.5             # Tighter grad clipping
)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_datasets["train"].select(range(4000))  # Subset for fast fine-tuning
)

# Start training
trainer.train()
# Explicitly save final model
trainer.save_model("./output_v5/fine_tuned_gpt2/final_model")
