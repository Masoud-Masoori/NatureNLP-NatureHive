import os
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from datasets import load_dataset
from nltk.translate.bleu_score import sentence_bleu
from rouge import Rouge
import jiwer

# ✅ Load the trained model
model_dir = "./output_v6/final_model"
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

print("🔵 Loading tokenizer and model...")
tokenizer = AutoTokenizer.from_pretrained(model_dir)
model = AutoModelForCausalLM.from_pretrained(model_dir).to(device)
model.eval()

results = []

##############################################
# 1. TEXT: BLEU, ROUGE, Perplexity, Tokens/sec
##############################################
text_dataset = load_dataset("squad", split="validation[:10%]")
prompts = [ex["context"] for ex in text_dataset.select(range(10))]
references = [ex["answers"]["text"][0] for ex in text_dataset.select(range(10))]

def evaluate_text(model, tokenizer, prompts, references):
    latencies, tokens_sec, perplexities, bleu_scores = [], [], [], []
    loss_fn = torch.nn.CrossEntropyLoss()
    rouge = Rouge()

    for prompt, ref in zip(prompts, references):
        inputs = tokenizer(prompt, return_tensors="pt").to(device)
        labels = inputs.input_ids.clone()

        with torch.no_grad():
            outputs = model(**inputs, labels=labels)

        loss = outputs.loss
        perplexities.append(torch.exp(loss).item())

        with torch.no_grad():
            gen_ids = model.generate(inputs.input_ids, max_length=100)
            gen_text = tokenizer.decode(gen_ids[0], skip_special_tokens=True)
        bleu_scores.append(sentence_bleu([ref.split()], gen_text.split()))

    return {
        "latency_avg": None,  # Skipped timing here
        "tokens_per_sec": None,
        "perplexity_avg": sum(perplexities) / len(perplexities),
        "bleu_avg": sum(bleu_scores) / len(bleu_scores),
    }

text_metrics = evaluate_text(model, tokenizer, prompts, references)
results.append(("Text", text_metrics))

##############################################
# 2. MATH ACCURACY (GSM8K)
##############################################
try:
    math_dataset = load_dataset("gsm8k", "main", split="test[:5%]")
    math_prompts = [ex["question"] for ex in math_dataset]
    math_answers = [ex["answer"] for ex in math_dataset]

    def evaluate_math(model, tokenizer, prompts, answers):
        correct = 0
        for prompt, ans in zip(prompts, answers):
            inputs = tokenizer(prompt, return_tensors="pt").to(device)
            with torch.no_grad():
                gen_ids = model.generate(inputs.input_ids, max_length=50)
            gen_text = tokenizer.decode(gen_ids[0], skip_special_tokens=True)
            if ans.strip() in gen_text:
                correct += 1
        return correct / len(prompts)

    math_acc = evaluate_math(model, tokenizer, math_prompts, math_answers)
    results.append(("Math (GSM8K)", {"accuracy": math_acc}))
except Exception as e:
    results.append(("Math (GSM8K)", f"⚠️ Failed to evaluate: {e}"))

##############################################
# 3. CODING (GitHub Code)
##############################################
try:
    coding_dataset = load_dataset("codeparrot/github-code", split="train[:0.1%]", trust_remote_code=True)
    coding_prompts = [ex["code"] for ex in coding_dataset.select(range(5))]

    def evaluate_code(model, tokenizer, prompts):
        correct = 0
        for prompt in prompts:
            inputs = tokenizer(prompt, return_tensors="pt").to(device)
            with torch.no_grad():
                gen_ids = model.generate(inputs.input_ids, max_length=100)
            gen_text = tokenizer.decode(gen_ids[0], skip_special_tokens=True)
            if len(gen_text.strip()) > 0:
                correct += 1
        return correct / len(prompts)

    code_acc = evaluate_code(model, tokenizer, coding_prompts)
    results.append(("Code (GitHub)", {"accuracy": code_acc}))
except Exception as e:
    results.append(("Code (GitHub)", f"⚠️ Failed to evaluate: {e}"))

##############################################
# 📊 FINAL REPORT
##############################################
print("\n📈 NatureNLP v6 Evaluation Results")
print("===================================")
for section, metrics in results:
    print(f"🔹 {section}:")
    if isinstance(metrics, dict):
        for key, val in metrics.items():
            print(f"   - {key}: {val}")
    else:
        print(f"   {metrics}")
