from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

model_dir = "./output_v6_light/final_model"
device = "cuda" if torch.cuda.is_available() else "cpu"

print("🔍 Loading model and tokenizer...")
model = AutoModelForCausalLM.from_pretrained(model_dir).to(device)
tokenizer = AutoTokenizer.from_pretrained(model_dir)

# Sample prompt
prompt = "The future of artificial intelligence is"
inputs = tokenizer(prompt, return_tensors="pt").to(device)

print("🧠 Generating response...")
with torch.no_grad():
    outputs = model.generate(**inputs, max_new_tokens=50)

print("📝 Output:")
print(tokenizer.decode(outputs[0], skip_special_tokens=True))
print("✅ Done!")