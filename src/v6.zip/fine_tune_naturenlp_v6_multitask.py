# 🔁 NatureNLP v6 - Safe Split-by-Split Tuner (LoRA + Resume + Minimal RAM)

import os
import json
import torch
from datasets import load_from_disk, concatenate_datasets
from transformers import AutoTokenizer, TrainingArguments, Trainer
from accelerate import Accelerator
from peft import get_peft_model, LoraConfig, TaskType, prepare_model_for_kbit_training
from transformers import AutoModelForCausalLM
import logging

# === Logging ===
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("NatureNLP")

# === Paths ===
huggingface_cache_dir = "H:/huggingface_cache"
tokenized_path = "D:/Ideas/NatureNLP/src/v6/tokenized_splits"
output_dir = "D:/Ideas/NatureNLP/src/v6/output_v6"
model_dir = "D:/Ideas/NatureNLP/models/mistral-7b"
os.makedirs(output_dir, exist_ok=True)

# === Environment Variables ===
os.environ.update({
    "HF_HOME": huggingface_cache_dir,
    "TRANSFORMERS_CACHE": huggingface_cache_dir,
    "HF_DATASETS_CACHE": huggingface_cache_dir,
    "PYTORCH_CUDA_ALLOC_CONF": "max_split_size_mb:32",
    "CUDA_LAUNCH_BLOCKING": "1",
})

# === Tokenizer + Model ===
logger.info("🔵 Loading tokenizer + model")
tokenizer = AutoTokenizer.from_pretrained(model_dir, use_fast=True, trust_remote_code=True)
model = AutoModelForCausalLM.from_pretrained(model_dir, torch_dtype=torch.bfloat16, trust_remote_code=True)

if tokenizer.pad_token is None:
    tokenizer.add_special_tokens({'pad_token': '[PAD]'})
    model.resize_token_embeddings(len(tokenizer))

# === LoRA Fine-Tuning Setup ===
model.enable_input_require_grads()
model = prepare_model_for_kbit_training(model)
lora_config = LoraConfig(
    r=4,
    lora_alpha=16,
    target_modules=["q_proj", "v_proj"],
    lora_dropout=0.05,
    bias="none",
    task_type=TaskType.CAUSAL_LM
)
model = get_peft_model(model, lora_config)
model.print_trainable_parameters()
model.train()

# === Training Config ===
training_args = TrainingArguments(
    output_dir=output_dir,
    per_device_train_batch_size=1,
    gradient_accumulation_steps=32,
    num_train_epochs=1,
    bf16=True,
    fp16=False,
    logging_steps=10,
    save_steps=250,
    save_total_limit=2,
    save_strategy="steps",
    evaluation_strategy="no",
    report_to="none",
    remove_unused_columns=True,
    gradient_checkpointing=True,
    overwrite_output_dir=False,
    save_safetensors=True,
)

# === Safe Train-Per-Chunk ===
accelerator = Accelerator()
model = accelerator.prepare(model)

split_chunks = [
    "codeparrot_1100_chunk_0",
    "codeparrot_1100_chunk_1",
    "gsm8k_50_all",
    "imdb_50_all"
]

for chunk_name in split_chunks:
    try:
        logger.info(f"🧩 Loading chunk: {chunk_name}")
        ds_path = os.path.join(tokenized_path, chunk_name)
        dataset = load_from_disk(ds_path)

        # Add labels = input_ids
        dataset = dataset.map(lambda x: {"labels": x["input_ids"]}, batched=True)

        trainer = Trainer(
            model=model,
            args=training_args,
            train_dataset=dataset,
        )

        logger.info(f"🚀 Training on chunk: {chunk_name}")
        trainer.train()

        logger.info(f"💾 Saving checkpoint for: {chunk_name}")
        model.save_pretrained(os.path.join(output_dir, f"checkpoint_{chunk_name}"))

    except Exception as e:
        logger.error(f"❌ Error training on {chunk_name}: {e}")

logger.info("🏁 All chunks processed successfully!")
