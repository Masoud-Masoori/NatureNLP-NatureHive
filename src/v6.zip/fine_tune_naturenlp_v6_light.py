import os
import torch
from datasets import load_dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
    DataCollatorForLanguageModeling,
)

# ✅ Use GPT2 for light fine-tuning
model_name = "gpt2"
cache_dir = "E:/huggingface_cache"

# 🔵 Load model/tokenizer
print("🔵 Loading tokenizer and model...")
tokenizer = AutoTokenizer.from_pretrained(model_name, cache_dir=cache_dir)
model = AutoModelForCausalLM.from_pretrained(model_name, cache_dir=cache_dir)

# ✅ Ensure padding for batching
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
    model.resize_token_embeddings(len(tokenizer))

# 🧩 Load dataset
print("🧩 Loading dataset (IMDB 1%)...")
dataset = load_dataset("imdb", split="train[:1%]", cache_dir=cache_dir)

def preprocess(example):
    return tokenizer(example["text"], truncation=True, padding="max_length", max_length=256)

tokenized_dataset = dataset.map(preprocess, batched=True, remove_columns=["text"])
tokenized_dataset.set_format("torch")

# ⚙️ Training args
print("⚙️ Preparing training arguments...")
training_args = TrainingArguments(
    output_dir="./output_v6_light",
    per_device_train_batch_size=2,
    gradient_accumulation_steps=4,
    num_train_epochs=1,
    logging_steps=10,
    save_strategy="epoch",
    fp16=True,
    push_to_hub=False,
)

# 🧠 Trainer setup
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_dataset,
    tokenizer=tokenizer,
    data_collator=DataCollatorForLanguageModeling(tokenizer, mlm=False),
)

# 🏋️ Fine-tune
print("🏋️ Starting training...")
trainer.train()

# 💾 Save model
trainer.save_model("./output_v6_light/final_model")
print("✅ Done training!")
