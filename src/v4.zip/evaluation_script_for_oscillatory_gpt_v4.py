# File: evaluation_script_for_oscillatory_gpt_v4.py

import time
import torch
from transformers import GPT2Tokenizer, GPT2LMHeadModel
from custom_gpt2_lmhead_v4 import CustomGPT2LMHeadModelV4
from torch.nn import CrossEntropyLoss

# Load tokenizer
tokenizer = GPT2Tokenizer.from_pretrained("gpt2-medium")

# Load NatureNLP v4 model
nature_model = CustomGPT2LMHeadModelV4.from_pretrained(
    "D:/Ideas/NatureNLP/src/v4/output/oscillatory_gpt2_v4/final_model",
    local_files_only=True
)
nature_model.eval()

# Load GPT-2 baseline
baseline_model = GPT2LMHeadModel.from_pretrained("gpt2-medium")
baseline_model.eval()

# Define evaluation prompts
prompts = [
    "Discuss the role of AI in modern healthcare.",
    "Explain the principles of quantum computing in simple terms.",
    "What are the ethical implications of artificial intelligence?",
    "Describe the rhythms of nature and how they influence life."
]

# Initialize metrics
results = []

# Evaluation loop for both models
for model_name, model in [("NatureNLP_v4", nature_model), ("GPT2_baseline", baseline_model)]:
    print(f"\nEvaluating {model_name}...\n")
    total_loss = 0
    total_tokens = 0
    total_latency = 0

    for prompt in prompts:
        inputs = tokenizer(prompt, return_tensors="pt")
        labels = inputs["input_ids"]
        
        # Measure latency
        start_time = time.time()
        with torch.no_grad():
            outputs = model(**inputs, labels=labels)
        end_time = time.time()

        # Compute loss and tokens/sec
        loss = outputs.loss.item()
        num_tokens = labels.numel()
        latency = end_time - start_time
        tokens_per_sec = num_tokens / latency

        total_loss += loss * num_tokens
        total_tokens += num_tokens
        total_latency += latency

        print(f"Prompt: {prompt}")
        print(f"Loss: {loss:.4f}, Latency: {latency:.4f} sec, Tokens/sec: {tokens_per_sec:.2f}\n")

    # Aggregate metrics
    perplexity = torch.exp(torch.tensor(total_loss / total_tokens)).item()
    avg_latency = total_latency / len(prompts)
    avg_tokens_per_sec = total_tokens / total_latency

    results.append({
        "model": model_name,
        "perplexity": perplexity,
        "avg_latency": avg_latency,
        "avg_tokens_per_sec": avg_tokens_per_sec
    })

# Save results
with open("benchmark_results_v4.txt", "w", encoding="utf-8") as f:
    for result in results:
        f.write(f"Model: {result['model']}\n")
        f.write(f"Perplexity: {result['perplexity']:.4f}\n")
        f.write(f"Average Latency: {result['avg_latency']:.4f} sec\n")
        f.write(f"Tokens/sec: {result['avg_tokens_per_sec']:.2f}\n\n")
        print(f"Model: {result['model']}, Perplexity: {result['perplexity']:.4f}, Avg Latency: {result['avg_latency']:.4f} sec, Tokens/sec: {result['avg_tokens_per_sec']:.2f}")
