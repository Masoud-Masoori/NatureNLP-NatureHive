# File: evaluate_generate_nlp_v4.py

from transformers import GPT2Tokenizer
from custom_gpt2_lmhead_v4 import CustomGPT2LMHeadModelV4
import torch

# Load tokenizer and model
tokenizer = GPT2Tokenizer.from_pretrained("gpt2-medium")
model = CustomGPT2LMHeadModelV4.from_pretrained(
    "D:/Ideas/NatureNLP/src/v4/output/oscillatory_gpt2_v4/final_model",
    local_files_only=True
)
model.eval()

# Example prompt
prompt = "The future of AI in healthcare is"
inputs = tokenizer(prompt, return_tensors="pt")

# Generation with sampling controls
outputs = model.generate(
    **inputs,
    max_length=100,
    num_return_sequences=1,
    temperature=0.8,   # Adds randomness
    top_k=50,          # Limits to top 50 tokens
    top_p=0.9,         # Nucleus sampling
    do_sample=True     # Enables sampling
)

generated_text = tokenizer.decode(outputs[0], skip_special_tokens=True)
print("Generated Text:\n", generated_text)

# Save output to file
with open("generated_output_v4.txt", "w", encoding="utf-8") as f:
    f.write(generated_text)
