# File: D:/Ideas/NatureNLP/src/v4/fine_tune_oscillatory_v4.py

import os
import torch
from datasets import load_dataset
from transformers import GPT2Tokenizer, Trainer, TrainingArguments, DataCollatorForLanguageModeling
from custom_gpt2_lmhead_v4 import CustomGPT2LMHeadModelV4  # Oscillatory Layer v4 integrated

# Load dataset (IMDB)
dataset = load_dataset("imdb")

# Reduce dataset size for quick testing
train_dataset = dataset["train"].shuffle(seed=42).select(range(2000))
test_dataset = dataset["test"].shuffle(seed=42).select(range(1000))

# Load tokenizer
model_path = os.path.abspath("../v3/base_model/gpt2_medium")  # Reuse v3 GPT-2 base
tokenizer = GPT2Tokenizer.from_pretrained(model_path)
tokenizer.pad_token = tokenizer.eos_token  # Fix pad_token warnings

def tokenize_function(examples):
    return tokenizer(examples["text"], padding="max_length", truncation=True, max_length=512)

train_dataset = train_dataset.map(tokenize_function, batched=True)
test_dataset = test_dataset.map(tokenize_function, batched=True)

# Load model
model = CustomGPT2LMHeadModelV4.from_pretrained(model_path)
model.resize_token_embeddings(len(tokenizer))

# Set up training arguments (compatible with older Transformers versions)
training_args = TrainingArguments(
    output_dir="./output/oscillatory_gpt2_v4_finetuned",
    overwrite_output_dir=True,
    num_train_epochs=1,
    per_device_train_batch_size=8,
    per_device_eval_batch_size=8,
    save_strategy="epoch",
    do_eval=True,  # Evaluation enabled
    logging_steps=10,  # Frequent logs
    save_total_limit=1,
    logging_dir="./logs",
    gradient_accumulation_steps=2,
    fp16=True,
    max_steps=500  # Short run for testing
)

data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)

# Initialize Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=test_dataset,
    data_collator=data_collator,
    tokenizer=tokenizer
)

# Start training
if __name__ == "__main__":
    print("Starting fine-tuning...")
    trainer.train()
    print("Training completed.")

    # Save final model
    model.save_pretrained("./output/oscillatory_gpt2_v4/final_model")
    tokenizer.save_pretrained("./output/oscillatory_gpt2_v4/final_model")
