# File: D:/Ideas/NatureNLP/src/v4/custom_gpt2_v4.py

from transformers import GPT2Model

class CustomGPT2ModelV4(GPT2Model):
    def __init__(self, config):
        super().__init__(config)
