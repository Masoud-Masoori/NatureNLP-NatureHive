# File: custom_gpt2_lmhead_v4.py

import torch
import torch.nn as nn
from transformers import GPT2LMHeadModel
from transformers.modeling_outputs import CausalLMOutputWithCrossAttentions
from oscillatory_layer_v4 import OscillatoryLayerV4  # Import Oscillatory Layer v4

class CustomGPT2LMHeadModelV4(GPT2LMHeadModel):
    def __init__(self, config):
        super().__init__(config)
        self.oscillatory = OscillatoryLayerV4(config)  # Integrate Oscillatory Layer v4
        self.osc_to_vocab = nn.Linear(config.hidden_size, config.vocab_size)  # Project oscillatory output to vocab space

    def forward(self, input_ids=None, attention_mask=None, labels=None, output_hidden_states=False, **kwargs):
        # Always request hidden states from GPT-2
        outputs = super().forward(
            input_ids=input_ids,
            attention_mask=attention_mask,
            labels=None,  # Handle loss computation manually below
            output_hidden_states=True,
            **kwargs
        )

        # Apply Oscillatory Layer v4 on GPT-2 last hidden states
        hidden_states = outputs.hidden_states[-1]  # Last layer hidden state (batch, seq_len, hidden_size)
        oscillatory_output = self.oscillatory(hidden_states)  # Apply oscillatory layer
        osc_logits = self.osc_to_vocab(oscillatory_output)   # Map oscillatory output to vocab space
        combined_logits = outputs.logits + osc_logits  # Combine base GPT-2 logits with oscillatory logits

        # Compute loss manually if labels are provided
        if labels is not None:
            shift_logits = combined_logits[..., :-1, :].contiguous()
            shift_labels = labels[..., 1:].contiguous()
            loss_fct = nn.CrossEntropyLoss()
            loss = loss_fct(shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1))
        else:
            loss = None

        # Return a compatible Hugging Face output object
        return CausalLMOutputWithCrossAttentions(
            loss=loss,
            logits=combined_logits,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
            cross_attentions=None
        )
